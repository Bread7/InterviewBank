from flask import Flask, render_template, jsonify, make_response, request
from authlib.jose import jwt
from Crypto.PublicKey import RSA

app = Flask(__name__)
FLAG = '----secret----'

posts = [
    {"id": 1, "user": "admin", "content": FLAG},
    {"id": 2, "user": "guest", "content": "Here is not flag"}]

def genkeys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def guestoken(private_key):
    header = {"alg": "RS256"}
    payload = {"user": "guest"}
    token = jwt.encode(header, payload, private_key)
    return token

@app.route('/')
def main():
    return render_template('index.html', posts=posts)

@app.route('/getcookie')
def getCookie():
    resp = make_response('hello guest')
    resp.set_cookie('session', token.decode('UTF-8'))
    return resp

@app.route('/api/jwt')
def public():
    return jsonify({'public_key': public_key.decode('UTF-8')})

@app.route('/post/<int:post_id>')
def post_detail(post_id):
    session = request.cookies.get('session')
    if session is None:
        return 'you need to getcookie'
    decoded = jwt.decode(session.encode(), public_key)
    print(decoded)
    post = next((post for post in posts if post["id"] == post_id), None)
    if post['id'] == 1:
        if decoded['user'] != 'admin':
            return 'you are not admin'

    return render_template('post_detail.html', post=post)


if __name__ == '__main__':
    private_key, public_key = genkeys()
    token = guestoken(private_key)
    app.run(host='0.0.0.0', port=2303)